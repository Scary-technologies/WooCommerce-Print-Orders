<?php
/*
Plugin Name: WooCommerce Print Orders
Description: An advanced localized plugin to print WooCommerce orders with an enhanced invoice layout, including more detailed information and additional output formats.
Version: 1
Author: PR-M
GitHub: https://github.com/Scary-technologies/
*/

// Prevent direct access to the file
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

// Add a custom action link in WooCommerce order list
add_action( 'woocommerce_admin_order_actions_end', 'custom_print_order_action' );
function custom_print_order_action( $order ) {
    $order_id = $order->get_id();
    echo '<a href="' . admin_url( 'admin-ajax.php?action=print_order&order_id=' . $order_id ) . '" class="button" target="_blank" style="background-color: #0073aa; color: #fff; border-radius: 5px; padding: 5px 10px;">پرینت سفارش</a>';
}

// Add custom bulk action to WooCommerce orders
add_filter( 'bulk_actions-edit-shop_order', 'register_bulk_print_orders' );
function register_bulk_print_orders( $bulk_actions ) {
    $bulk_actions['bulk_print_orders'] = 'ساخت گزارش به صورت لیستی';
    return $bulk_actions;
}

// Add JavaScript to handle custom bulk action
add_action( 'admin_footer', 'bulk_action_print_orders_javascript' );
function bulk_action_print_orders_javascript() {
    global $post_type;
    if ( 'shop_order' == $post_type ) {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                jQuery('<option>').val('bulk_print_orders').text('ساخت گزارش به صورت لیستی').appendTo("select[name='action']");
                jQuery('<option>').val('bulk_print_orders').text('ساخت گزارش به صورت لیستی').appendTo("select[name='action2']");
            });
        </script>
        <?php
    }
}

// Handle custom bulk action
add_action( 'admin_init', 'handle_bulk_print_orders' );
function handle_bulk_print_orders() {
    if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'bulk_print_orders' ) {
        $order_ids = isset( $_REQUEST['post'] ) ? array_map( 'absint', $_REQUEST['post'] ) : [];
        if ( empty( $order_ids ) ) {
            return;
        }

        // Generate report for selected orders
        $report_data = '';
        foreach ( $order_ids as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( $order ) {
                $report_data .= '<h2>سفارش شماره ' . $order_id . '</h2>';
                $report_data .= '<p><strong>نام مشتری:</strong> ' . esc_html( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) . '</p>';
                $report_data .= '<p><strong>ایمیل:</strong> ' . esc_html( $order->get_billing_email() ) . '</p>';
                $report_data .= '<p><strong>تلفن:</strong> ' . esc_html( $order->get_billing_phone() ) . '</p>';
                $report_data .= '<p><strong>جمع کل:</strong> ' . wc_price( $order->get_total() ) . '</p>';
                $report_data .= '<hr>'; // Divider between orders
            }
        }

        // Display report
        echo '<html><head><title>گزارش سفارشات</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; direction: rtl; text-align: right; background-color: #f9f9f9; padding: 20px; }
            h2 { color: #0073aa; text-align: right; }
            hr { margin: 20px 0; }
        </style>
        </head><body>';
        echo '<h1 style="text-align: right;">گزارش سفارشات انتخاب شده</h1>';
        echo $report_data;
        echo '</body></html>';
        exit;
    }
}

// Handle print order action
add_action('wp_ajax_print_order', 'custom_print_order_function' );
function custom_print_order_function() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        wp_die( 'شما اجازه دسترسی به این صفحه را ندارید.' );
    }

    if ( ! isset( $_GET['order_id'] ) ) {
        wp_die( 'شناسه سفارش نامعتبر است.' );
    }

    $order_id = intval( $_GET['order_id'] );
    $order = wc_get_order( $order_id );

    if ( ! $order ) {
        wp_die( 'شناسه سفارش نامعتبر است.' );
    }

    // Ask user for fields to include in the report
    if ( ! isset( $_GET['fields'] ) ) {
        echo '<form method="get" action="' . admin_url( 'admin-ajax.php' ) . '" style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; background-color: #f9f9f9; direction: rtl; text-align: right;">
                <input type="hidden" name="action" value="print_order">
                <input type="hidden" name="order_id" value="' . $order_id . '">
                <h2 style="text-align: center; color: #0073aa;">انتخاب فیلدهای گزارش</h2>
                <label style="display: block; margin-bottom: 10px;"><input type="checkbox" name="fields[]" value="customer_info" checked> اطلاعات مشتری</label>
                <label style="display: block; margin-bottom: 10px;"><input type="checkbox" name="fields[]" value="shipping_info" checked> اطلاعات ارسال</label>
                <label style="display: block; margin-bottom: 10px;"><input type="checkbox" name="fields[]" value="order_items" checked> آیتم‌های سفارش</label>
                <label style="display: block; margin-bottom: 10px;"><input type="checkbox" name="fields[]" value="payment_info" checked> اطلاعات پرداخت</label>
                <input type="submit" value="نمایش گزارش" style="background-color: #0073aa; color: #fff; border: none; border-radius: 5px; padding: 10px 20px; cursor: pointer;">
              </form>';
        exit;
    }

    $fields = $_GET['fields'];

    // Select page size based on user input
    $page_size = isset( $_GET['page_size'] ) ? sanitize_text_field( $_GET['page_size'] ) : 'A4';

    // Generate HTML for printing
    ob_start();
    echo '<html><head><title>پرینت سفارش #' . $order_id . '</title>';
    echo '<style>
        @page { size: ' . $page_size . '; }
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; direction: rtl; text-align: right; background-color: #f9f9f9; padding: 20px; }
        .invoice-container { max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; background-color: #fff; direction: rtl; text-align: right; }
        h1 { text-align: center; color: #0073aa; text-align: right; }
        h2 { color: #0073aa; border-bottom: 2px solid #0073aa; padding-bottom: 5px; text-align: right; }
        .order-info, .customer-info, .shipping-info { margin-bottom: 20px; text-align: right; }
        .order-items { border-collapse: collapse; width: 100%; margin-bottom: 20px; direction: rtl; text-align: right; }
        .order-items th, .order-items td { border: 1px solid #ddd; padding: 8px; text-align: right; }
        .order-items th { background-color: #f2f2f2; color: #333; }
        .total { font-size: 1.5em; font-weight: bold; text-align: right; color: #0073aa; }
    </style></head><body>';

    echo '<div class="invoice-container">';
    echo '<h1>سفارش شماره ' . $order_id . '</h1>';

    // Customer Information
    if ( in_array( 'customer_info', $fields ) ) {
        echo '<div class="customer-info">';
        echo '<h2>اطلاعات مشتری</h2>';
        echo '<p><strong>نام و نام خانوادگی:</strong> ' . esc_html( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) . '</p>';
        echo '<p><strong>ایمیل:</strong> ' . esc_html( $order->get_billing_email() ) . '</p>';
        echo '<p><strong>تلفن:</strong> ' . esc_html( $order->get_billing_phone() ) . '</p>';
        echo '<p><strong>آدرس صورتحساب:</strong> ' . esc_html( $order->get_formatted_billing_address() ) . '</p>';
        echo '</div>';
    }

    // Shipping Information
    if ( in_array( 'shipping_info', $fields ) ) {
        echo '<div class="shipping-info">';
        echo '<h2>اطلاعات ارسال</h2>';
        echo '<p><strong>نام و نام خانوادگی گیرنده:</strong> ' . esc_html( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() ) . '</p>';
        echo '<p><strong>آدرس ارسال:</strong> ' . esc_html( $order->get_formatted_shipping_address() ) . '</p>';
        echo '<p><strong>روش ارسال:</strong> ' . esc_html( $order->get_shipping_method() ) . '</p>';
        echo '</div>';
    }

    // Order Items
    if ( in_array( 'order_items', $fields ) ) {
        echo '<h2>آیتم‌های سفارش</h2>';
        echo '<table class="order-items">';
        echo '<tr><th>نام آیتم</th><th>تعداد</th><th>قیمت</th><th>جمع جزء</th></tr>';
        foreach ( $order->get_items() as $item_id => $item ) {
            echo '<tr><td>' . esc_html( $item->get_name() ) . '</td><td>' . intval( $item->get_quantity() ) . '</td><td>' . wc_price( $item->get_total() / $item->get_quantity() ) . '</td><td>' . wc_price( $item->get_total() ) . '</td></tr>';
        }
        echo '</table>';
    }

    // Payment Information
    if ( in_array( 'payment_info', $fields ) ) {
        echo '<div class="order-info">';
        echo '<h2>اطلاعات پرداخت</h2>';
        echo '<p><strong>روش پرداخت:</strong> ' . esc_html( $order->get_payment_method_title() ) . '</p>';
        echo '<p class="total"><strong>جمع کل:</strong> ' . wc_price( $order->get_total() ) . '</p>';
        echo '</div>';
    }

    echo '</div>';
    echo '</body></html>';
    echo $html;
    exit;
}
